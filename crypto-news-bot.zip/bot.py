#!/usr/bin/env python3
"""
Bot d'alertes Telegram : Clearpool (CPOOL) & Quant (QNT)
- Annonces officielles (Medium Clearpool, Google News ciblé Quant)
- Presse crypto (CoinDesk, Cointelegraph, The Block, Decrypt, CryptoSlate, Bitcoin.com...)
- Agrégateur CryptoPanic (optionnel, clé API gratuite)
- Comptes X via RSSHub (optionnel)
- Alertes de prix (CoinGecko, variation sur 1 h)

Modes :
  python bot.py --once   -> une passe puis quitte (GitHub Actions / cron)
  python bot.py          -> boucle infinie, vérifie toutes les CHECK_INTERVAL secondes (PC / serveur)
"""
import html
import json
import os
import re
import sys
import time
import urllib.parse
from datetime import datetime, timezone

import feedparser
import requests

# ---------------------------------------------------------------- Config
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
CRYPTOPANIC_TOKEN = os.environ.get("CRYPTOPANIC_TOKEN", "")      # optionnel
RSSHUB_BASE = os.environ.get("RSSHUB_BASE", "")                  # optionnel, ex: https://rsshub.monserveur.fr
CHECK_INTERVAL = int(os.environ.get("CHECK_INTERVAL", "60"))     # secondes (mode boucle)
PRICE_ALERT_PCT = float(os.environ.get("PRICE_ALERT_PCT", "5"))  # % sur 1 h
PRICE_COOLDOWN = int(os.environ.get("PRICE_COOLDOWN", "3600"))   # 1 alerte prix max / h / token
MAX_AGE_HOURS = int(os.environ.get("MAX_AGE_HOURS", "48"))       # ignore les articles plus vieux
STATE_FILE = os.environ.get("STATE_FILE", os.path.join(os.path.dirname(os.path.abspath(__file__)), "state.json"))

UA = {"User-Agent": "Mozilla/5.0 (CryptoNewsBot; +telegram)"}

# Mots-clés stricts (évite les faux positifs sur "quant" = trading quantitatif)
PROJECTS = {
    "CPOOL": {
        "name": "Clearpool",
        "emoji": "🟣",
        "coingecko": "clearpool",
        "patterns": [r"\bclearpool\b", r"\bCPOOL\b", r"\bcpxrp\b", r"\bozean\b"],
    },
    "QNT": {
        "name": "Quant",
        "emoji": "🔷",
        "coingecko": "quant-network",
        "patterns": [r"\bquant network\b", r"\bQNT\b", r"\boverledger\b", r"\bquant fusion\b",
                     r"\bgilbert verdian\b", r"\bquant\b(?=.{0,40}\b(crypto|token|blockchain|tokeni[sz]|bank|interop))"],
    },
}

IMPORTANT_KW = re.compile(
    r"partner|partenariat|collaborat|integrat|list(s|ed|ing)\b|listing|binance|coinbase|kraken|upbit|"
    r"bank|banque|central bank|cbdc|ecb|bce|swift|launch|mainnet|lance|acquisi|funding|lev[ée]e|"
    r"regulat|sec\b|mica|hack|exploit|delist|airdrop|burn",
    re.I,
)

def gnews(q):
    return "https://news.google.com/rss/search?" + urllib.parse.urlencode(
        {"q": q + " when:2d", "hl": "en-US", "gl": "US", "ceid": "US:en"})

# (label, url, filtrer_par_mots_cles?, type)
FEEDS = [
    # --- Officiel
    ("Clearpool (Medium officiel)", "https://clearpool.medium.com/feed", False, "officiel", "CPOOL"),
    ("Google News · Clearpool", gnews('"Clearpool" OR "CPOOL"'), True, "news", None),
    ("Google News · Quant", gnews('"Quant Network" OR "Overledger" OR "QNT"'), True, "news", None),
    ("Google News FR · Clearpool/Quant", "https://news.google.com/rss/search?" + urllib.parse.urlencode(
        {"q": '"Clearpool" OR "Quant Network" OR "Overledger" when:2d', "hl": "fr", "gl": "FR", "ceid": "FR:fr"}), True, "news", None),
    # --- Presse crypto (filtrée par mots-clés)
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/", True, "presse", None),
    ("Cointelegraph", "https://cointelegraph.com/rss", True, "presse", None),
    ("The Block", "https://www.theblock.co/rss.xml", True, "presse", None),
    ("Decrypt", "https://decrypt.co/feed", True, "presse", None),
    ("CryptoSlate", "https://cryptoslate.com/feed/", True, "presse", None),
    ("Bitcoin.com News", "https://news.bitcoin.com/feed/", True, "presse", None),
    ("CryptoNews", "https://cryptonews.com/news/feed/", True, "presse", None),
    ("The Defiant", "https://thedefiant.io/api/feed", True, "presse", None),
    ("Journal du Coin", "https://journalducoin.com/feed/", True, "presse", None),
    ("Cryptoast", "https://cryptoast.fr/feed/", True, "presse", None),
    # --- Communauté
    ("Reddit r/QuantNetwork", "https://www.reddit.com/r/QuantNetwork/new/.rss", False, "communauté", "QNT"),
]

# Comptes X officiels (nécessite une instance RSSHub)
X_ACCOUNTS = [("ClearpoolFin", "CPOOL"), ("quant_network", "QNT"), ("gverdian", "QNT")]


# ---------------------------------------------------------------- State
def load_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            s = json.load(f)
    except Exception:
        s = {}
    s.setdefault("seen", [])
    s.setdefault("last_price_alert", {})
    s.setdefault("initialized", False)
    return s

def save_state(s):
    s["seen"] = s["seen"][-3000:]
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=1)


# ---------------------------------------------------------------- Helpers
def norm_key(link, title):
    t = re.sub(r"\W+", " ", (title or "").lower()).strip()[:90]
    return t or (link or "")

def match_projects(text):
    found = []
    for sym, p in PROJECTS.items():
        for pat in p["patterns"]:
            if re.search(pat, text, re.I):
                found.append(sym)
                break
    return found

def strip_html(s):
    return re.sub(r"<[^>]+>", " ", s or "")

def entry_time(e):
    for k in ("published_parsed", "updated_parsed"):
        if e.get(k):
            return datetime(*e[k][:6], tzinfo=timezone.utc)
    return None

def send_telegram(text):
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        print("[DRY-RUN]", text.replace("\n", " | "))
        return True
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    for _ in range(3):
        r = requests.post(url, data={"chat_id": TELEGRAM_CHAT_ID, "text": text,
                                     "parse_mode": "HTML", "disable_web_page_preview": "false"}, timeout=20)
        if r.status_code == 429:
            time.sleep(r.json().get("parameters", {}).get("retry_after", 5))
            continue
        if not r.ok:
            print("Telegram error:", r.status_code, r.text[:200])
        return r.ok
    return False

def fmt_news(syms, title, link, source, kind, published):
    tags = " ".join(f"{PROJECTS[s]['emoji']} #{s}" for s in syms)
    hot = "🔥 <b>IMPORTANT</b>\n" if IMPORTANT_KW.search(title) else ""
    icon = {"officiel": "📢", "presse": "📰", "news": "🗞", "communauté": "💬", "x": "𝕏", "agrégateur": "📡"}.get(kind, "📰")
    when = published.strftime("%d/%m %H:%M UTC") if published else ""
    return (f"{hot}{tags}\n{icon} <b>{html.escape(title)}</b>\n"
            f"<i>{html.escape(source)}</i> · {when}\n{html.escape(link)}")


# ---------------------------------------------------------------- Sources
def collect_feeds():
    items = []
    feeds = list(FEEDS)
    if RSSHUB_BASE:
        for acc, sym in X_ACCOUNTS:
            feeds.append((f"X @{acc}", f"{RSSHUB_BASE.rstrip('/')}/twitter/user/{acc}", False, "x", sym))
    for label, url, filt, kind, forced in feeds:
        try:
            r = requests.get(url, headers=UA, timeout=20)
            d = feedparser.parse(r.content)
        except Exception as ex:
            print(f"! {label}: {ex}")
            continue
        for e in d.entries[:40]:
            title = (e.get("title") or "").strip()
            link = e.get("link") or ""
            text = f"{title} {strip_html(e.get('summary', ''))}"
            syms = match_projects(text)
            if forced and forced not in syms:
                syms = [forced] + syms
            if filt and not syms:
                continue
            if not syms:
                continue
            src = label
            if "news.google.com" in url and e.get("source", {}).get("title"):
                src = e["source"]["title"] + " (via Google News)"
            items.append((syms, title, link, src, kind, entry_time(e)))
    return items

def collect_cryptopanic():
    if not CRYPTOPANIC_TOKEN:
        return []
    items = []
    for base in ("https://cryptopanic.com/api/developer/v2/posts/", "https://cryptopanic.com/api/v1/posts/"):
        try:
            r = requests.get(base, params={"auth_token": CRYPTOPANIC_TOKEN, "currencies": "CPOOL,QNT",
                                           "public": "true", "kind": "news"}, headers=UA, timeout=20)
            if not r.ok:
                continue
            for p in r.json().get("results", []):
                title = p.get("title", "")
                syms = [c["code"] for c in p.get("currencies", []) or [] if c.get("code") in PROJECTS] \
                    or match_projects(title)
                if not syms:
                    continue
                link = p.get("original_url") or p.get("url") or ""
                src = (p.get("source") or {}).get("title", "CryptoPanic")
                try:
                    t = datetime.fromisoformat(p.get("published_at", "").replace("Z", "+00:00"))
                except Exception:
                    t = None
                items.append((syms, title, link, src + " (via CryptoPanic)", "agrégateur", t))
            break
        except Exception as ex:
            print("! CryptoPanic:", ex)
    return items

def check_prices(state):
    ids = ",".join(p["coingecko"] for p in PROJECTS.values())
    try:
        r = requests.get("https://api.coingecko.com/api/v3/coins/markets", headers=UA, timeout=20,
                         params={"vs_currency": "usd", "ids": ids, "price_change_percentage": "1h,24h"})
        data = r.json()
    except Exception as ex:
        print("! CoinGecko:", ex)
        return
    now = time.time()
    for c in data if isinstance(data, list) else []:
        sym = c.get("symbol", "").upper()
        if sym not in PROJECTS:
            continue
        ch1 = c.get("price_change_percentage_1h_in_currency") or 0
        ch24 = c.get("price_change_percentage_24h_in_currency") or 0
        if abs(ch1) >= PRICE_ALERT_PCT and now - state["last_price_alert"].get(sym, 0) > PRICE_COOLDOWN:
            arrow = "🚀" if ch1 > 0 else "🔻"
            p = PROJECTS[sym]
            send_telegram(
                f"{arrow} <b>{p['name']} ({sym})</b> {ch1:+.2f} % en 1 h\n"
                f"Prix : <b>${c.get('current_price'):,.4f}</b> · 24 h : {ch24:+.2f} %\n"
                f"Volume 24 h : ${c.get('total_volume', 0):,.0f}\n"
                f"https://www.coingecko.com/en/coins/{p['coingecko']}")
            state["last_price_alert"][sym] = now


# ---------------------------------------------------------------- Main
def run_once(state):
    items = collect_feeds() + collect_cryptopanic()
    seen = set(state["seen"])
    cutoff = time.time() - MAX_AGE_HOURS * 3600
    # plus ancien -> plus récent
    items.sort(key=lambda x: x[5].timestamp() if x[5] else 0)
    first_run = not state["initialized"]
    sent = 0
    for syms, title, link, src, kind, t in items:
        key = norm_key(link, title)
        if key in seen:
            continue
        seen.add(key)
        state["seen"].append(key)
        if t and t.timestamp() < cutoff:
            continue
        if first_run:
            continue  # 1er lancement : on mémorise sans spammer l'historique
        if send_telegram(fmt_news(syms, title, link, src, kind, t)):
            sent += 1
            time.sleep(1)
    if first_run:
        state["initialized"] = True
        send_telegram("✅ Bot Clearpool / Quant actif. Tu recevras les nouvelles actus et les alertes de prix ici.")
    check_prices(state)
    save_state(state)
    print(f"{datetime.now():%H:%M:%S} - {len(items)} articles scannés, {sent} envoyés")

def main():
    state = load_state()
    if "--once" in sys.argv:
        run_once(state)
        return
    while True:
        try:
            run_once(state)
        except Exception as ex:
            print("Erreur:", ex)
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
