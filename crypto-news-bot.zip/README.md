# Bot Telegram Clearpool (CPOOL) & Quant (QNT)

Il t'envoie sur Telegram :
- 📢 les annonces officielles (Medium Clearpool, comptes X en option)
- 📰 les articles de la presse crypto (CoinDesk, Cointelegraph, The Block, Decrypt, Cryptoast, Journal du Coin…) qui parlent de Clearpool ou de Quant
- 🔥 un tag IMPORTANT pour les partenariats, listings, banques, lancements, hacks
- 🚀/🔻 une alerte si CPOOL ou QNT bouge de ±5 % en 1 h (CoinGecko)

## 1. Créer ton bot Telegram (2 min)
1. Dans Telegram, ouvre **@BotFather** → `/newbot` → choisis un nom → copie le **token**.
2. Envoie n'importe quel message à ton nouveau bot.
3. Ouvre **@userinfobot** → il te donne ton **chat ID** (un nombre).

## 2. Le mettre en ligne gratuitement (GitHub Actions)
1. Crée un compte sur github.com → **New repository** → nom `crypto-news-bot` → **Private**.
2. **Add file → Upload files** : dépose tout le contenu du zip (y compris le dossier `.github`).
3. **Settings → Secrets and variables → Actions → New repository secret** :
   - `TELEGRAM_TOKEN` = le token de BotFather
   - `TELEGRAM_CHAT_ID` = ton chat ID
4. Onglet **Actions** → active les workflows → **Clearpool-Quant news bot → Run workflow**.
5. Tu reçois « ✅ Bot actif ». Ensuite ça tourne tout seul.

Délai : vérification toutes les **60 s** pendant chaque cycle ; GitHub relance le cycle toutes les ~5 min (parfois 10-15 min aux heures chargées). Pour un vrai temps réel à la minute, 24h/24 : lance `python bot.py` sur un PC allumé, un Raspberry Pi ou un petit VPS (ex. Oracle Cloud gratuit).

## 3. Options pour plus de précision
| Secret | À quoi ça sert | Où l'obtenir |
|---|---|---|
| `CRYPTOPANIC_TOKEN` | Agrégateur crypto qui tague les news par token (très fiable pour CPOOL/QNT) | cryptopanic.com/developers/api (gratuit) |
| `RSSHUB_BASE` | Tweets officiels @ClearpoolFin, @quant_network, @gverdian | ton instance RSSHub (docs.rsshub.app) |

Réglages (variables d'env.) : `PRICE_ALERT_PCT` (défaut 5), `CHECK_INTERVAL` (défaut 60 s).

Au 1er lancement, le bot mémorise les articles déjà publiés sans te les envoyer (pas de spam).
